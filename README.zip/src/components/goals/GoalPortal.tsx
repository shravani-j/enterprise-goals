"use client";

import React, { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { DndContext, DragEndEvent, useDraggable, useDroppable, PointerSensor, useSensor, useSensors } from "@dnd-kit/core";
import { CSS } from "@dnd-kit/utilities";
import {
  Target,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Clock,
  MessageSquare,
  Sparkles,
  ChevronRight,
  GripVertical,
  Filter,
  X,
  AlertCircle,
  Calendar,
  AlertTriangle,
  UserCheck,
  Send,
  Loader2,
  ArrowRight
} from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";

// Interface definitions
interface User {
  id: string;
  name: string | null;
  email: string;
  role: string;
  managerId?: string | null;
}

interface Comment {
  id: string;
  content: string;
  createdAt: string;
  user: {
    id: string;
    name: string | null;
    role: string;
  };
}

interface CheckIn {
  id: string;
  progress: number;
  notes: string | null;
  achievements: string | null;
  blockers: string | null;
  nextSteps: string | null;
  createdAt: string;
}

interface Goal {
  id: string;
  title: string;
  description: string | null;
  weightage: number;
  status: "DRAFT" | "SUBMITTED" | "RETURNED_FOR_REWORK" | "APPROVED" | "COMPLETED";
  priority: "LOW" | "MEDIUM" | "HIGH";
  startDate: string | null;
  dueDate: string | null;
  progress: number;
  userId: string;
  user: User;
  comments: Comment[];
  checkIns: CheckIn[];
  createdAt: string;
}

interface Toast {
  id: string;
  message: string;
  type: "success" | "error" | "info";
}

export function GoalPortal() {
  const { data: session } = useSession();
  const currentUserId = session?.user?.id;
  const currentUserRole = session?.user?.role || "EMPLOYEE";

  // State Management
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const [reports, setReports] = useState<User[]>([]);
  const [selectedReportId, setSelectedReportId] = useState<string>("");
  const [toasts, setToasts] = useState<Toast[]>([]);

  // Dialog State
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState<Goal | null>(null);
  const [isEditMode, setIsEditMode] = useState(false);

  // Form State (New / Edit Goal)
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [weightage, setWeightage] = useState(10);
  const [priority, setPriority] = useState<"LOW" | "MEDIUM" | "HIGH">("MEDIUM");
  const [startDate, setStartDate] = useState("");
  const [dueDate, setDueDate] = useState("");

  // Action State (Check-in & Comment)
  const [checkInProgress, setCheckInProgress] = useState(0);
  const [checkInNotes, setCheckInNotes] = useState("");
  const [checkInAchievements, setCheckInAchievements] = useState("");
  const [checkInBlockers, setCheckInBlockers] = useState("");
  const [checkInNextSteps, setCheckInNextSteps] = useState("");
  const [commentText, setCommentText] = useState("");
  const [reworkCommentText, setReworkCommentText] = useState("");
  const [showReworkInput, setShowReworkInput] = useState(false);
  const [submittingAction, setSubmittingAction] = useState(false);

  // DnD Sensors config to prevent collision with clicks
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  // Toast Trigger
  const triggerToast = (message: string, type: "success" | "error" | "info" = "success") => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  // Load Initial Data
  const loadData = async () => {
    try {
      setLoading(true);
      // Get Reports if Manager/Admin
      if (currentUserRole === "MANAGER" || currentUserRole === "ADMIN") {
        const repRes = await fetch("/api/users/reports");
        if (repRes.ok) {
          const repData = await repRes.json();
          setReports(repData);
        }
      }

      // Fetch Goals
      const url = selectedReportId
        ? `/api/goals?userId=${selectedReportId}`
        : "/api/goals";
      const goalRes = await fetch(url);
      if (goalRes.ok) {
        const goalData = await goalRes.json();
        setGoals(goalData);
      } else {
        triggerToast("Failed to fetch goals", "error");
      }
    } catch (err) {
      console.error(err);
      triggerToast("Error connecting to database", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (session) {
      loadData();
    }
  }, [session, selectedReportId]);

  // Statistics Computations
  const activeGoals = goals.filter((g) => g.status !== "COMPLETED");
  const totalWeightage = goals.reduce((sum, g) => sum + g.weightage, 0);
  const averageProgress = goals.length
    ? Math.round(goals.reduce((sum, g) => sum + g.progress, 0) / goals.length)
    : 0;

  // Handles drag end and performs workflow changes
  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over) return;

    const goalId = active.id as string;
    const targetStatus = over.id as Goal["status"];

    const draggedGoal = goals.find((g) => g.id === goalId);
    if (!draggedGoal) return;

    if (draggedGoal.status === targetStatus) return;

    // Validate workflow transition rules on drag
    let isValid = false;
    if (currentUserRole === "EMPLOYEE") {
      if (
        (draggedGoal.status === "DRAFT" && targetStatus === "SUBMITTED") ||
        (draggedGoal.status === "SUBMITTED" && targetStatus === "DRAFT") ||
        (draggedGoal.status === "RETURNED_FOR_REWORK" && targetStatus === "SUBMITTED") ||
        (draggedGoal.status === "APPROVED" && targetStatus === "COMPLETED") ||
        (draggedGoal.status === "RETURNED_FOR_REWORK" && targetStatus === "DRAFT")
      ) {
        isValid = true;
      }
    } else if (currentUserRole === "MANAGER") {
      if (
        (draggedGoal.status === "SUBMITTED" &&
          (targetStatus === "APPROVED" || targetStatus === "RETURNED_FOR_REWORK")) ||
        (draggedGoal.status === "APPROVED" && targetStatus === "COMPLETED")
      ) {
        isValid = true;
      }
    } else if (currentUserRole === "ADMIN") {
      isValid = true;
    }

    if (!isValid) {
      triggerToast(
        `Invalid action for your role: Cannot transition goal from ${draggedGoal.status} to ${targetStatus}`,
        "error"
      );
      return;
    }

    // Special case: Returning for rework via drag requires comments. We will open modal instead
    if (targetStatus === "RETURNED_FOR_REWORK") {
      setSelectedGoal(draggedGoal);
      setIsEditMode(false);
      setShowReworkInput(true);
      triggerToast("Please provide feedback comments to return for rework", "info");
      return;
    }

    // Process drag update
    try {
      const res = await fetch(`/api/goals/${goalId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: targetStatus })
      });

      if (res.ok) {
        const updated = await res.json();
        setGoals((prev) => prev.map((g) => (g.id === goalId ? updated : g)));
        triggerToast(`Goal updated to ${targetStatus} successfully!`);
      } else {
        const errData = await res.json();
        triggerToast(errData.message || "Failed to update goal state", "error");
      }
    } catch (err) {
      console.error(err);
      triggerToast("Error updating goal status", "error");
    }
  };

  // Create Goal Action
  const handleCreateGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (weightage < 10 || weightage > 100) {
      triggerToast("Weightage must be between 10 and 100", "error");
      return;
    }

    if (activeGoals.length >= 8) {
      triggerToast("Employee cannot have more than 8 active goals", "error");
      return;
    }

    if (totalWeightage + weightage > 100) {
      triggerToast(`Total assigned weightage cannot exceed 100. Remaining allowance: ${100 - totalWeightage}`, "error");
      return;
    }

    try {
      setSubmittingAction(true);
      const res = await fetch("/api/goals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          weightage,
          priority,
          startDate: startDate || null,
          dueDate: dueDate || null
        })
      });

      if (res.ok) {
        const newGoal = await res.json();
        setGoals((prev) => [newGoal, ...prev]);
        setIsCreateOpen(false);
        triggerToast("Goal created in DRAFT successfully!");
        // Reset state
        setTitle("");
        setDescription("");
        setWeightage(10);
        setPriority("MEDIUM");
        setStartDate("");
        setDueDate("");
      } else {
        const errData = await res.json();
        triggerToast(errData.message || "Failed to create goal", "error");
      }
    } catch (err) {
      console.error(err);
      triggerToast("Error connecting to create goal", "error");
    } finally {
      setSubmittingAction(false);
    }
  };

  // Edit Goal Action
  const handleEditGoal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGoal) return;

    try {
      setSubmittingAction(true);
      const res = await fetch(`/api/goals/${selectedGoal.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          weightage,
          priority,
          startDate: startDate || null,
          dueDate: dueDate || null
        })
      });

      if (res.ok) {
        const updated = await res.json();
        setGoals((prev) => prev.map((g) => (g.id === selectedGoal.id ? updated : g)));
        setSelectedGoal(updated);
        setIsEditMode(false);
        triggerToast("Goal edited successfully!");
      } else {
        const errData = await res.json();
        triggerToast(errData.message || "Failed to edit goal", "error");
      }
    } catch (err) {
      console.error(err);
      triggerToast("Error editing goal", "error");
    } finally {
      setSubmittingAction(false);
    }
  };

  // Delete Goal Action
  const handleDeleteGoal = async (id: string) => {
    if (!confirm("Are you sure you want to delete this goal?")) return;

    try {
      const res = await fetch(`/api/goals/${id}`, {
        method: "DELETE"
      });

      if (res.ok) {
        setGoals((prev) => prev.filter((g) => g.id !== id));
        setSelectedGoal(null);
        triggerToast("Goal deleted successfully!");
      } else {
        const errData = await res.json();
        triggerToast(errData.message || "Failed to delete goal", "error");
      }
    } catch (err) {
      console.error(err);
      triggerToast("Error deleting goal", "error");
    }
  };

  // Comment Creation Action
  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGoal || !commentText.trim()) return;

    try {
      setSubmittingAction(true);
      const res = await fetch(`/api/goals/${selectedGoal.id}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: commentText })
      });

      if (res.ok) {
        const newComment = await res.json();
        const updatedGoal = {
          ...selectedGoal,
          comments: [...(selectedGoal.comments || []), newComment]
        };
        setGoals((prev) => prev.map((g) => (g.id === selectedGoal.id ? updatedGoal : g)));
        setSelectedGoal(updatedGoal);
        setCommentText("");
        triggerToast("Comment added!");
      } else {
        triggerToast("Failed to add comment", "error");
      }
    } catch (err) {
      console.error(err);
      triggerToast("Error adding comment", "error");
    } finally {
      setSubmittingAction(false);
    }
  };

  // Check-In (Progress Update) Action
  const handleCheckIn = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGoal) return;

    try {
      setSubmittingAction(true);
      const res = await fetch(`/api/goals/${selectedGoal.id}/checkins`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          progress: checkInProgress,
          notes: checkInNotes,
          achievements: checkInAchievements,
          blockers: checkInBlockers,
          nextSteps: checkInNextSteps
        })
      });

      if (res.ok) {
        const data = await res.json();
        const updatedGoal = {
          ...selectedGoal,
          progress: data.goal.progress,
          status: data.goal.status,
          checkIns: [data.checkIn, ...(selectedGoal.checkIns || [])]
        };
        setGoals((prev) => prev.map((g) => (g.id === selectedGoal.id ? updatedGoal : g)));
        setSelectedGoal(updatedGoal);
        setCheckInNotes("");
        setCheckInAchievements("");
        setCheckInBlockers("");
        setCheckInNextSteps("");
        triggerToast(`Checked in successfully! Progress: ${checkInProgress}%`);
      } else {
        const errData = await res.json();
        triggerToast(errData.message || "Failed to submit check-in", "error");
      }
    } catch (err) {
      console.error(err);
      triggerToast("Error performing check-in", "error");
    } finally {
      setSubmittingAction(false);
    }
  };

  // Manager Approve Action
  const handleApprove = async () => {
    if (!selectedGoal) return;

    try {
      const res = await fetch(`/api/goals/${selectedGoal.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "APPROVED" })
      });

      if (res.ok) {
        const updated = await res.json();
        setGoals((prev) => prev.map((g) => (g.id === selectedGoal.id ? updated : g)));
        setSelectedGoal(updated);
        triggerToast("Goal approved successfully!");
      } else {
        triggerToast("Failed to approve goal", "error");
      }
    } catch (err) {
      console.error(err);
      triggerToast("Error approving goal", "error");
    }
  };

  // Manager Return for Rework Action
  const handleReturnForRework = async () => {
    if (!selectedGoal || !reworkCommentText.trim()) {
      triggerToast("Please provide a reason or feedback comment", "error");
      return;
    }

    try {
      const res = await fetch(`/api/goals/${selectedGoal.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          status: "RETURNED_FOR_REWORK",
          comment: reworkCommentText
        })
      });

      if (res.ok) {
        const updated = await res.json();
        setGoals((prev) => prev.map((g) => (g.id === selectedGoal.id ? updated : g)));
        setSelectedGoal(updated);
        setShowReworkInput(false);
        setReworkCommentText("");
        triggerToast("Goal returned for rework with feedback!");
      } else {
        triggerToast("Failed to process action", "error");
      }
    } catch (err) {
      console.error(err);
      triggerToast("Error processing request", "error");
    }
  };

  // Employee Submit Action
  const handleSubmitGoal = async (id: string) => {
    try {
      const res = await fetch(`/api/goals/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "SUBMITTED" })
      });

      if (res.ok) {
        const updated = await res.json();
        setGoals((prev) => prev.map((g) => (g.id === id ? updated : g)));
        if (selectedGoal?.id === id) setSelectedGoal(updated);
        triggerToast("Goal submitted to manager for approval!");
      } else {
        const errData = await res.json();
        triggerToast(errData.message || "Failed to submit goal", "error");
      }
    } catch (err) {
      console.error(err);
      triggerToast("Error submitting goal", "error");
    }
  };

  // Employee Withdraw Action
  const handleWithdrawGoal = async (id: string) => {
    try {
      const res = await fetch(`/api/goals/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "DRAFT" })
      });

      if (res.ok) {
        const updated = await res.json();
        setGoals((prev) => prev.map((g) => (g.id === id ? updated : g)));
        if (selectedGoal?.id === id) setSelectedGoal(updated);
        triggerToast("Goal withdrawn back to Draft successfully!");
      } else {
        const errData = await res.json();
        triggerToast(errData.message || "Failed to withdraw goal", "error");
      }
    } catch (err) {
      console.error(err);
      triggerToast("Error withdrawing goal", "error");
    }
  };

  // Fetch fresh goal details including comments & checkins from dynamic API on click
  const handleOpenDetails = async (goal: Goal) => {
    // Clear comment and check-in inputs to avoid state leaks/caching across goals!
    setCommentText("");
    setReworkCommentText("");
    setShowReworkInput(false);
    setCheckInProgress(goal.progress);
    setCheckInNotes("");
    setCheckInAchievements("");
    setCheckInBlockers("");
    setCheckInNextSteps("");

    setSelectedGoal(goal);
    try {
      const res = await fetch(`/api/goals/${goal.id}`);
      if (res.ok) {
        const freshGoal = await res.json();
        setGoals((prev) => prev.map((g) => (g.id === goal.id ? freshGoal : g)));
        setSelectedGoal(freshGoal);
        setCheckInProgress(freshGoal.progress);
      }
    } catch (err) {
      console.error("Error loading fresh goal details:", err);
    }
  };

  // Open Edit Mode
  const openEditMode = (goal: Goal) => {
    setTitle(goal.title);
    setDescription(goal.description || "");
    setWeightage(goal.weightage);
    setPriority(goal.priority);
    setStartDate(goal.startDate ? goal.startDate.split("T")[0] : "");
    setDueDate(goal.dueDate ? goal.dueDate.split("T")[0] : "");
    setIsEditMode(true);
  };

  const getPriorityBadgeColor = (p: Goal["priority"]) => {
    switch (p) {
      case "HIGH":
        return "bg-rose-50 border-rose-200 text-rose-700 dark:bg-rose-950/20 dark:border-rose-900/30";
      case "MEDIUM":
        return "bg-amber-50 border-amber-200 text-amber-700 dark:bg-amber-950/20 dark:border-amber-900/30";
      case "LOW":
        return "bg-emerald-50 border-emerald-200 text-emerald-700 dark:bg-emerald-950/20 dark:border-emerald-900/30";
    }
  };

  const getStatusBadgeColor = (s: Goal["status"]) => {
    switch (s) {
      case "DRAFT":
        return "bg-zinc-100 text-zinc-800 border-zinc-200";
      case "SUBMITTED":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "RETURNED_FOR_REWORK":
        return "bg-orange-100 text-orange-800 border-orange-200";
      case "APPROVED":
        return "bg-amber-100 text-amber-800 border-amber-200";
      case "COMPLETED":
        return "bg-green-100 text-green-800 border-green-200";
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 md:px-0 pb-16">
      {/* Toast Box Container */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 max-w-md w-full pointer-events-none">
        <AnimatePresence>
          {toasts.map((toast) => (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9, transition: { duration: 0.15 } }}
              className={`p-4 rounded-xl shadow-lg border pointer-events-auto flex items-start gap-3 backdrop-blur-md bg-white/95 dark:bg-zinc-900/95 ${
                toast.type === "success"
                  ? "border-emerald-200 dark:border-emerald-900/30"
                  : toast.type === "error"
                  ? "border-rose-200 dark:border-rose-900/30"
                  : "border-amber-200 dark:border-amber-900/30"
              }`}
            >
              {toast.type === "success" && (
                <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              )}
              {toast.type === "error" && (
                <AlertCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
              )}
              {toast.type === "info" && (
                <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
              )}
              <div className="flex-1">
                <p className="text-sm font-semibold text-zinc-950 dark:text-zinc-550">
                  {toast.type === "success" ? "Success" : toast.type === "error" ? "Error" : "Info"}
                </p>
                <p className="text-xs text-zinc-500 mt-0.5">{toast.message}</p>
              </div>
              <button
                onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
                className="text-zinc-400 hover:text-zinc-600 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* Profile/Filter Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 bg-white/70 dark:bg-zinc-900/30 p-6 rounded-2xl border border-zinc-200/80 dark:border-zinc-800/80 backdrop-blur-md">
        <div>
          <h1 className="text-3xl font-poppins font-bold tracking-tight text-zinc-950 dark:text-zinc-550">
            Goal Setting & <span className="text-[var(--color-dijon)]">Workflow</span> Portal
          </h1>
          <p className="text-zinc-500 text-sm mt-1">
            Build, execute, review, and track performance goals inside the secure enterprise sandbox.
          </p>
        </div>

        {/* Manager Team Filtering */}
        {(currentUserRole === "MANAGER" || currentUserRole === "ADMIN") && (
          <div className="flex items-center gap-3 bg-zinc-50 dark:bg-zinc-900 p-2.5 rounded-xl border border-zinc-200">
            <Filter className="w-4 h-4 text-zinc-500" />
            <span className="text-xs font-semibold text-zinc-700">Team Filter:</span>
            <select
              value={selectedReportId}
              onChange={(e) => setSelectedReportId(e.target.value)}
              className="bg-transparent text-sm focus:outline-none font-medium pr-8"
            >
              <option value="">My Personal Goals</option>
              {reports.map((report) => (
                <option key={report.id} value={report.id}>
                  {report.name} ({report.email})
                </option>
              ))}
            </select>
          </div>
        )}

        {currentUserRole === "EMPLOYEE" && (
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => setIsCreateOpen(true)}
            className="flex items-center justify-center gap-2 bg-[var(--color-dijon)] text-white font-semibold py-2.5 px-5 rounded-xl hover:bg-[var(--color-dijon)]/95 shadow-sm transition-all text-sm shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" /> Create Goal
          </motion.button>
        )}
      </div>

      {/* KPI Section */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200/85 p-6 rounded-2xl shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider block">
              Active Goals Limit
            </span>
            <span className="text-2xl font-bold mt-1 text-zinc-800 block">
              {activeGoals.length} / 8
            </span>
            <span className="text-xs text-zinc-500 mt-1 block">Maximum allowed is 8 active</span>
          </div>
          <div className="bg-amber-50 dark:bg-amber-950/20 p-3 rounded-2xl text-[var(--color-dijon)]">
            <Target className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200/85 p-6 rounded-2xl shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider block">
              Total Goals Weightage
            </span>
            <span className="text-2xl font-bold mt-1 text-zinc-800 block">
              {totalWeightage} %
            </span>
            <span className="text-xs text-zinc-500 mt-1 block">Remaining allowance: {100 - totalWeightage}%</span>
          </div>
          <div className="bg-amber-50 dark:bg-amber-950/20 p-3 rounded-2xl text-[var(--color-mimosa)]">
            <Sparkles className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white dark:bg-zinc-900 border border-zinc-200/85 p-6 rounded-2xl shadow-sm flex items-center justify-between">
          <div>
            <span className="text-xs font-semibold text-zinc-400 uppercase tracking-wider block">
              Overall Average Progress
            </span>
            <span className="text-2xl font-bold mt-1 text-zinc-800 block">
              {averageProgress}%
            </span>
            <div className="w-32 bg-zinc-100 rounded-full h-1.5 mt-2">
              <div
                className="bg-[var(--color-dijon)] h-1.5 rounded-full"
                style={{ width: `${averageProgress}%` }}
              />
            </div>
          </div>
          <div className="bg-amber-50 dark:bg-amber-950/20 p-3 rounded-2xl text-[var(--color-flax)]">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Loading & Empty States */}
      {loading ? (
        <div className="flex flex-col items-center justify-center min-h-[400px]">
          <Loader2 className="w-12 h-12 text-[var(--color-dijon)] animate-spin" />
          <p className="text-zinc-500 text-sm mt-4 font-semibold">Loading goals from Sandbox SQLite...</p>
        </div>
      ) : goals.length === 0 ? (
        <div className="bg-white dark:bg-zinc-900 border border-zinc-200 rounded-3xl p-12 text-center max-w-xl mx-auto shadow-sm">
          <Target className="w-16 h-16 text-zinc-300 mx-auto" />
          <h2 className="text-xl font-bold text-zinc-800 mt-6">No Goals Configured</h2>
          <p className="text-zinc-500 mt-2 text-sm">
            {selectedReportId
              ? "This team member hasn't created any goals yet."
              : "You haven't set up any performance goals for this cycle yet. Create one to get started."}
          </p>
          {!selectedReportId && currentUserRole === "EMPLOYEE" && (
            <button
              onClick={() => setIsCreateOpen(true)}
              className="mt-6 inline-flex items-center gap-2 bg-[var(--color-dijon)] text-white font-semibold py-2.5 px-6 rounded-xl hover:bg-[var(--color-dijon)]/95 shadow-sm text-sm cursor-pointer"
            >
              <Plus className="w-4.5 h-4.5" /> Set First Goal
            </button>
          )}
        </div>
      ) : (
        /* DnD Context Board */
        <DndContext sensors={sensors} onDragEnd={handleDragEnd}>
          <div className="flex gap-6 items-start overflow-x-auto pb-6 select-none w-full scrollbar-thin scrollbar-thumb-zinc-200 scrollbar-track-transparent">
            {/* 1. DRAFT */}
            <DroppableColumn
              id="DRAFT"
              title="Draft"
              count={goals.filter((g) => g.status === "DRAFT").length}
              bgClass="bg-zinc-50/50 dark:bg-zinc-900/10 border border-zinc-200/60"
            >
              {goals
                .filter((g) => g.status === "DRAFT")
                .map((goal) => (
                  <DraggableGoalCard
                    key={goal.id}
                    goal={goal}
                    onClick={() => handleOpenDetails(goal)}
                    getPriorityBadgeColor={getPriorityBadgeColor}
                  />
                ))}
            </DroppableColumn>

            {/* 2. SUBMITTED */}
            <DroppableColumn
              id="SUBMITTED"
              title="Submitted"
              count={goals.filter((g) => g.status === "SUBMITTED").length}
              bgClass="bg-blue-50/10 dark:bg-blue-950/5 border border-blue-100"
            >
              {goals
                .filter((g) => g.status === "SUBMITTED")
                .map((goal) => (
                  <DraggableGoalCard
                    key={goal.id}
                    goal={goal}
                    onClick={() => handleOpenDetails(goal)}
                    getPriorityBadgeColor={getPriorityBadgeColor}
                  />
                ))}
            </DroppableColumn>

            {/* 3. RETURNED FOR REWORK */}
            <DroppableColumn
              id="RETURNED_FOR_REWORK"
              title="Rework"
              count={goals.filter((g) => g.status === "RETURNED_FOR_REWORK").length}
              bgClass="bg-orange-50/10 dark:bg-orange-950/5 border border-orange-100"
            >
              {goals
                .filter((g) => g.status === "RETURNED_FOR_REWORK")
                .map((goal) => (
                  <DraggableGoalCard
                    key={goal.id}
                    goal={goal}
                    onClick={() => handleOpenDetails(goal)}
                    getPriorityBadgeColor={getPriorityBadgeColor}
                  />
                ))}
            </DroppableColumn>

            {/* 4. APPROVED */}
            <DroppableColumn
              id="APPROVED"
              title="Approved"
              count={goals.filter((g) => g.status === "APPROVED").length}
              bgClass="bg-amber-50/10 dark:bg-amber-950/5 border border-amber-100/50"
            >
              {goals
                .filter((g) => g.status === "APPROVED")
                .map((goal) => (
                  <DraggableGoalCard
                    key={goal.id}
                    goal={goal}
                    onClick={() => handleOpenDetails(goal)}
                    getPriorityBadgeColor={getPriorityBadgeColor}
                  />
                ))}
            </DroppableColumn>

            {/* 5. COMPLETED */}
            <DroppableColumn
              id="COMPLETED"
              title="Completed"
              count={goals.filter((g) => g.status === "COMPLETED").length}
              bgClass="bg-emerald-50/10 dark:bg-emerald-950/5 border border-emerald-100"
            >
              {goals
                .filter((g) => g.status === "COMPLETED")
                .map((goal) => (
                  <DraggableGoalCard
                    key={goal.id}
                    goal={goal}
                    onClick={() => handleOpenDetails(goal)}
                    getPriorityBadgeColor={getPriorityBadgeColor}
                  />
                ))}
            </DroppableColumn>
          </div>
        </DndContext>
      )}

      {/* CREATE GOAL MODAL DIALOG */}
      <AnimatePresence>
        {isCreateOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCreateOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            {/* Modal Box */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-3xl p-8 max-w-xl w-full shadow-2xl relative z-10 overflow-y-auto max-h-[90vh]"
            >
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold flex items-center gap-3 text-zinc-950 dark:text-zinc-550">
                  <Target className="text-[var(--color-dijon)] w-6 h-6" /> Create Performance Goal
                </h2>
                <button
                  onClick={() => setIsCreateOpen(false)}
                  className="p-1 rounded-lg hover:bg-zinc-100 dark:hover:bg-zinc-800 text-zinc-400 hover:text-zinc-600 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreateGoal} className="space-y-5">
                <div>
                  <label className="text-xs font-bold uppercase text-zinc-500 tracking-wider block mb-2">
                    Goal Title <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Optimize Database Indexes for Sandbox Portal"
                    className="w-full bg-zinc-50/50 border border-zinc-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30 transition-all"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold uppercase text-zinc-500 tracking-wider block mb-2">
                    Description
                  </label>
                  <textarea
                    rows={3}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="e.g. Conduct deep analytical audits on SQL queries and implement indexes to reduce database response times."
                    className="w-full bg-zinc-50/50 border border-zinc-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30 transition-all resize-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold uppercase text-zinc-500 tracking-wider block mb-2">
                      Weightage (%) <span className="text-rose-500">*</span>
                    </label>
                    <input
                      type="number"
                      required
                      min={10}
                      max={100}
                      value={weightage}
                      onChange={(e) => setWeightage(Number(e.target.value))}
                      className="w-full bg-zinc-50/50 border border-zinc-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30 transition-all"
                    />
                    <span className="text-[10px] text-zinc-400 mt-1 block">Limit: 10% to 100%</span>
                  </div>

                  <div>
                    <label className="text-xs font-bold uppercase text-zinc-500 tracking-wider block mb-2">
                      Priority <span className="text-rose-500">*</span>
                    </label>
                    <select
                      value={priority}
                      onChange={(e) => setPriority(e.target.value as any)}
                      className="w-full bg-zinc-50/50 border border-zinc-200 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30 transition-all"
                    >
                      <option value="LOW">Low</option>
                      <option value="MEDIUM">Medium</option>
                      <option value="HIGH">High</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold uppercase text-zinc-500 tracking-wider block mb-2">
                      Start Date
                    </label>
                    <div className="relative">
                      <Calendar className="w-4 h-4 text-zinc-400 absolute left-3.5 top-3.5" />
                      <input
                        type="date"
                        value={startDate}
                        onChange={(e) => setStartDate(e.target.value)}
                        className="w-full bg-zinc-50/50 border border-zinc-200 rounded-xl pl-10 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30 transition-all"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-bold uppercase text-zinc-500 tracking-wider block mb-2">
                      Due Date
                    </label>
                    <div className="relative">
                      <Calendar className="w-4 h-4 text-zinc-400 absolute left-3.5 top-3.5" />
                      <input
                        type="date"
                        value={dueDate}
                        onChange={(e) => setDueDate(e.target.value)}
                        className="w-full bg-zinc-50/50 border border-zinc-200 rounded-xl pl-10 pr-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30 transition-all"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 justify-end pt-4 border-t border-zinc-100">
                  <button
                    type="button"
                    onClick={() => setIsCreateOpen(false)}
                    className="py-2.5 px-5 rounded-xl border border-zinc-200 hover:bg-zinc-50 text-sm font-semibold transition-colors cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submittingAction}
                    className="py-2.5 px-6 rounded-xl bg-[var(--color-dijon)] text-white hover:bg-[var(--color-dijon)]/95 text-sm font-semibold shadow-sm transition-all cursor-pointer flex items-center gap-2"
                  >
                    {submittingAction ? (
                      <>
                        <Loader2 className="w-4.5 h-4.5 animate-spin" /> Saving...
                      </>
                    ) : (
                      "Save Draft"
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* GOAL DETAILS, EDIT, COMMENT, AND CHECK-IN DIALOG */}
      <AnimatePresence>
        {selectedGoal && (
          <div className="fixed inset-0 z-50 flex items-center justify-end">
            {/* Overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => {
                setSelectedGoal(null);
                setIsEditMode(false);
                setShowReworkInput(false);
                setCommentText("");
                setReworkCommentText("");
              }}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />

            {/* Sidebar Slide-over Panel */}
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="bg-white dark:bg-zinc-900 border-l border-zinc-200 dark:border-zinc-800 w-full max-w-xl h-full shadow-2xl relative z-10 flex flex-col"
            >
              {/* Header */}
              <div className="p-6 border-b border-zinc-200 flex justify-between items-start gap-4">
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={`text-[10px] font-bold tracking-wider px-2 py-0.5 rounded-full border ${getPriorityBadgeColor(
                        selectedGoal.priority
                      )}`}
                    >
                      {selectedGoal.priority} PRIORITY
                    </span>
                    <span
                      className={`text-[10px] font-bold tracking-wider px-2.5 py-0.5 rounded-full border ${getStatusBadgeColor(
                        selectedGoal.status
                      )}`}
                    >
                      {selectedGoal.status}
                    </span>
                  </div>
                  <h2 className="text-xl font-bold text-zinc-900 mt-2">
                    {isEditMode ? "Edit Goal" : selectedGoal.title}
                  </h2>
                  <p className="text-xs text-zinc-500 mt-1">
                    Owner: <span className="font-semibold">{selectedGoal.user.name}</span> ({selectedGoal.user.email})
                  </p>
                </div>
                <button
                  onClick={() => {
                    setSelectedGoal(null);
                    setIsEditMode(false);
                    setShowReworkInput(false);
                    setCommentText("");
                    setReworkCommentText("");
                  }}
                  className="p-1 rounded-lg hover:bg-zinc-100 text-zinc-400 hover:text-zinc-650 transition-colors shrink-0"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Scrollable Content */}
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {isEditMode ? (
                  // EDIT MODE FORM
                  <form onSubmit={handleEditGoal} className="space-y-4">
                    <div>
                      <label className="text-xs font-bold uppercase text-zinc-500 tracking-wider block mb-1">
                        Goal Title <span className="text-rose-500">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={title}
                        onChange={(e) => setTitle(e.target.value)}
                        className="w-full bg-zinc-50/50 border border-zinc-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold uppercase text-zinc-500 tracking-wider block mb-1">
                        Description
                      </label>
                      <textarea
                        rows={3}
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        className="w-full bg-zinc-50/50 border border-zinc-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30 resize-none"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-xs font-bold uppercase text-zinc-500 tracking-wider block mb-1">
                          Weightage (%) <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="number"
                          required
                          min={10}
                          max={100}
                          value={weightage}
                          onChange={(e) => setWeightage(Number(e.target.value))}
                          className="w-full bg-zinc-50/50 border border-zinc-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30"
                        />
                      </div>

                      <div>
                        <label className="text-xs font-bold uppercase text-zinc-500 tracking-wider block mb-1">
                          Priority <span className="text-rose-500">*</span>
                        </label>
                        <select
                          value={priority}
                          onChange={(e) => setPriority(e.target.value as any)}
                          className="w-full bg-zinc-50/50 border border-zinc-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30"
                        >
                          <option value="LOW">Low</option>
                          <option value="MEDIUM">Medium</option>
                          <option value="HIGH">High</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-xs font-bold uppercase text-zinc-500 tracking-wider block mb-1">
                          Start Date
                        </label>
                        <input
                          type="date"
                          value={startDate}
                          onChange={(e) => setStartDate(e.target.value)}
                          className="w-full bg-zinc-50/50 border border-zinc-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="text-xs font-bold uppercase text-zinc-500 tracking-wider block mb-1">
                          Due Date
                        </label>
                        <input
                          type="date"
                          value={dueDate}
                          onChange={(e) => setDueDate(e.target.value)}
                          className="w-full bg-zinc-50/50 border border-zinc-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="flex gap-3 justify-end pt-4">
                      <button
                        type="button"
                        onClick={() => setIsEditMode(false)}
                        className="py-2 px-4 rounded-xl border border-zinc-200 text-sm font-semibold hover:bg-zinc-50 cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={submittingAction}
                        className="py-2 px-5 rounded-xl bg-[var(--color-dijon)] text-white font-semibold hover:bg-[var(--color-dijon)]/95 shadow-sm text-sm cursor-pointer flex items-center gap-1"
                      >
                        {submittingAction && <Loader2 className="w-4 h-4 animate-spin" />} Update
                      </button>
                    </div>
                  </form>
                ) : (
                  // DETAIL FEEDBACK & METRICS
                  <div className="space-y-6">
                    {/* Metrics Row */}
                    <div className="grid grid-cols-3 gap-3 bg-zinc-50 p-4 rounded-xl border border-zinc-150">
                      <div className="text-center">
                        <span className="text-[10px] text-zinc-400 font-bold tracking-wider uppercase block">
                          Weightage
                        </span>
                        <span className="text-lg font-extrabold text-zinc-800 mt-1 block">
                          {selectedGoal.weightage}%
                        </span>
                      </div>
                      <div className="text-center border-x border-zinc-200">
                        <span className="text-[10px] text-zinc-400 font-bold tracking-wider uppercase block">
                          Progress
                        </span>
                        <span className="text-lg font-extrabold text-zinc-800 mt-1 block">
                          {selectedGoal.progress}%
                        </span>
                      </div>
                      <div className="text-center">
                        <span className="text-[10px] text-zinc-400 font-bold tracking-wider uppercase block">
                          Due Date
                        </span>
                        <span className="text-xs font-bold text-zinc-800 mt-2 block">
                          {selectedGoal.dueDate
                            ? new Date(selectedGoal.dueDate).toLocaleDateString()
                            : "No Date"}
                        </span>
                      </div>
                    </div>

                    {/* Goal Description */}
                    <div>
                      <h4 className="text-xs font-bold uppercase text-zinc-400 tracking-wider">
                        Goal Description
                      </h4>
                      <p className="text-sm text-zinc-650 mt-1.5 leading-relaxed bg-zinc-50/30 p-3 border rounded-xl">
                        {selectedGoal.description || "No description provided."}
                      </p>
                    </div>

                    {/* Timeline */}
                    <div className="flex gap-4 text-xs text-zinc-500 font-medium">
                      {selectedGoal.startDate && (
                        <span>
                          Start: <b>{new Date(selectedGoal.startDate).toLocaleDateString()}</b>
                        </span>
                      )}
                      {selectedGoal.createdAt && (
                        <span>
                          Created: <b>{new Date(selectedGoal.createdAt).toLocaleDateString()}</b>
                        </span>
                      )}
                    </div>

                    {/* CHECK-IN SECTION (ONLY IF APPROVED & GOAL OWNER) */}
                    {selectedGoal.status === "APPROVED" &&
                      selectedGoal.userId === currentUserId && (
                        <div className="bg-zinc-50/60 border border-zinc-200/80 p-5 rounded-2xl space-y-4">
                          <h4 className="text-sm font-bold text-zinc-800 flex items-center gap-2">
                            <Clock className="w-4 h-4 text-[var(--color-dijon)]" /> Perform Progress Check-in
                          </h4>
                          <form onSubmit={handleCheckIn} className="space-y-4">
                            <div>
                              <div className="flex justify-between items-center mb-1.5 text-xs font-bold text-zinc-550">
                                <span>Progress Percentage</span>
                                <span className="text-[var(--color-dijon)] text-sm font-black">
                                  {checkInProgress}%
                                </span>
                              </div>
                              <input
                                type="range"
                                min={selectedGoal.progress}
                                max={100}
                                value={checkInProgress}
                                onChange={(e) => setCheckInProgress(Number(e.target.value))}
                                className="w-full accent-[var(--color-dijon)] cursor-pointer"
                              />
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                              <div>
                                <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">
                                  Achievements & Wins
                                </label>
                                <textarea
                                  rows={2}
                                  value={checkInAchievements}
                                  onChange={(e) => setCheckInAchievements(e.target.value)}
                                  placeholder="What milestones did you accomplish?"
                                  className="w-full bg-white border border-zinc-200 rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30 resize-none"
                                />
                              </div>

                              <div>
                                <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">
                                  Blockers & Hurdles
                                </label>
                                <textarea
                                  rows={2}
                                  value={checkInBlockers}
                                  onChange={(e) => setCheckInBlockers(e.target.value)}
                                  placeholder="Are there any dependencies or blockers?"
                                  className="w-full bg-white border border-zinc-200 rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30 resize-none"
                                />
                              </div>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                              <div>
                                <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">
                                  Next Steps
                                </label>
                                <textarea
                                  rows={2}
                                  value={checkInNextSteps}
                                  onChange={(e) => setCheckInNextSteps(e.target.value)}
                                  placeholder="What will you focus on next?"
                                  className="w-full bg-white border border-zinc-200 rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30 resize-none"
                                />
                              </div>

                              <div>
                                <label className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider block mb-1">
                                  General Notes
                                </label>
                                <textarea
                                  rows={2}
                                  value={checkInNotes}
                                  onChange={(e) => setCheckInNotes(e.target.value)}
                                  placeholder="Any additional updates or comments..."
                                  className="w-full bg-white border border-zinc-200 rounded-xl px-3.5 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30 resize-none"
                                />
                              </div>
                            </div>

                            <div className="flex justify-end pt-1">
                              <button
                                type="submit"
                                disabled={submittingAction}
                                className="bg-[var(--color-dijon)] text-white font-semibold py-2 px-5 rounded-xl hover:bg-[var(--color-dijon)]/95 shadow-sm text-xs cursor-pointer flex items-center gap-1.5 transition-all"
                              >
                                {submittingAction ? (
                                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                ) : (
                                  <Clock className="w-3.5 h-3.5" />
                                )}{" "}
                                Submit Check-in
                              </button>
                            </div>
                          </form>
                        </div>
                      )}

                    {/* MANAGER REWORK REASON INPUT PANEL */}
                    {showReworkInput && (
                      <div className="bg-orange-50/30 border border-orange-100 p-5 rounded-2xl space-y-3">
                        <h4 className="text-sm font-bold text-zinc-850 flex items-center gap-2">
                          <AlertTriangle className="w-4 h-4 text-orange-500" /> Rework Feedback Comment
                        </h4>
                        <textarea
                          rows={2.5}
                          value={reworkCommentText}
                          onChange={(e) => setReworkCommentText(e.target.value)}
                          placeholder="Provide descriptive reason explaining why the goal is returned for rework..."
                          className="w-full bg-white border border-zinc-250 rounded-xl px-4 py-2 text-xs focus:outline-none"
                        />
                        <div className="flex justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setShowReworkInput(false)}
                            className="py-1 px-3 border border-zinc-200 rounded-lg text-xs font-semibold hover:bg-zinc-50 cursor-pointer"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={handleReturnForRework}
                            className="bg-orange-600 text-white font-semibold py-1 px-3 rounded-lg hover:bg-orange-700 text-xs cursor-pointer"
                          >
                            Submit Back
                          </button>
                        </div>
                      </div>
                    )}

                    {/* COMMENTS / DISCUSSIONS LOOP FEEDBACK */}
                    <div className="space-y-4 pt-4 border-t border-zinc-150">
                      <h4 className="text-xs font-bold uppercase text-zinc-400 tracking-wider flex items-center gap-2">
                        <MessageSquare className="w-4 h-4" /> Discussion Feedback Loop
                      </h4>

                      {/* Comments Feed */}
                      <div className="space-y-3.5 max-h-[220px] overflow-y-auto pr-1">
                        {(selectedGoal.comments || []).length === 0 ? (
                          <p className="text-xs text-zinc-400 italic">No feedback messages yet.</p>
                        ) : (
                          (selectedGoal.comments || []).map((comm) => (
                            <div
                              key={comm.id}
                              className={`p-3 rounded-xl border flex flex-col gap-1 max-w-[90%] ${
                                comm.user.id === currentUserId
                                  ? "bg-zinc-50 border-zinc-200/80 ml-auto items-end"
                                  : "bg-white border-zinc-200 items-start mr-auto"
                              }`}
                            >
                              <div className="flex items-center gap-1.5 text-[10px] font-bold text-zinc-500">
                                <span>{comm.user.name}</span>
                                <span className="bg-zinc-200 px-1 rounded text-[8px]">
                                  {comm.user.role}
                                </span>
                                <span>•</span>
                                <span>{new Date(comm.createdAt).toLocaleTimeString()}</span>
                              </div>
                              <p className="text-xs text-zinc-800 leading-normal">{comm.content}</p>
                            </div>
                          ))
                        )}
                      </div>

                      {/* Add comment Form */}
                      <form onSubmit={handleAddComment} className="flex gap-2">
                        <input
                          type="text"
                          value={commentText}
                          onChange={(e) => setCommentText(e.target.value)}
                          placeholder="Type your response/feedback..."
                          className="flex-1 bg-zinc-50 border border-zinc-250 rounded-xl px-4 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-[var(--color-dijon)]/30"
                        />
                        <button
                          type="submit"
                          disabled={submittingAction}
                          className="bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-semibold px-4 py-2 rounded-xl transition-all cursor-pointer flex items-center gap-1.5 shrink-0 shadow-sm"
                        >
                          <Send className="w-3.5 h-3.5" /> Post Comment
                        </button>
                      </form>
                    </div>

                    {/* CHECK-IN TIMELINE HISTORY */}
                    {selectedGoal.checkIns && (selectedGoal.checkIns || []).length > 0 && (
                      <div className="space-y-4 pt-4 border-t border-zinc-150">
                        <h4 className="text-xs font-bold uppercase text-zinc-400 tracking-wider flex items-center gap-2">
                          <Clock className="w-4 h-4" /> Check-In Timeline History
                        </h4>
                        <div className="relative pl-6 border-l-2 border-dashed border-zinc-200 ml-3 space-y-6 max-h-[300px] overflow-y-auto pr-1">
                          {(selectedGoal.checkIns || []).map((check) => (
                            <div key={check.id} className="relative">
                              {/* Timeline Node Icon */}
                              <div className="absolute -left-[31px] top-1 bg-white border-2 border-[var(--color-dijon)] rounded-full p-1 w-5 h-5 flex items-center justify-center shrink-0 shadow-sm">
                                <span className="w-1.5 h-1.5 rounded-full bg-[var(--color-dijon)]" />
                              </div>

                              <div className="bg-white border border-zinc-200 rounded-2xl p-4 space-y-2.5 shadow-sm hover:shadow-md transition-shadow">
                                {/* Header Info */}
                                <div className="flex justify-between items-center border-b border-zinc-100 pb-1.5">
                                  <span className="text-[10px] text-zinc-400 font-bold uppercase">
                                    {new Date(check.createdAt).toLocaleString()}
                                  </span>
                                  <span className="font-extrabold text-[var(--color-dijon)] bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200 text-[10px] shrink-0 shadow-sm">
                                    {check.progress}% Progress
                                  </span>
                                </div>

                                {/* Formatted fields */}
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                                  {check.achievements && (
                                    <div className="bg-emerald-50/50 border border-emerald-100 p-2.5 rounded-xl">
                                      <span className="text-[9px] font-bold text-emerald-800 uppercase tracking-wider block mb-0.5">
                                        Achievements & Wins
                                      </span>
                                      <p className="text-emerald-950 leading-snug">{check.achievements}</p>
                                    </div>
                                  )}

                                  {check.blockers && (
                                    <div className="bg-rose-50/50 border border-rose-100 p-2.5 rounded-xl">
                                      <span className="text-[9px] font-bold text-rose-800 uppercase tracking-wider block mb-0.5">
                                        Blockers & Hurdles
                                      </span>
                                      <p className="text-rose-955 leading-snug">{check.blockers}</p>
                                    </div>
                                  )}

                                  {check.nextSteps && (
                                    <div className="bg-blue-50/50 border border-blue-100 p-2.5 rounded-xl">
                                      <span className="text-[9px] font-bold text-blue-800 uppercase tracking-wider block mb-0.5">
                                        Next Steps
                                      </span>
                                      <p className="text-blue-955 leading-snug">{check.nextSteps}</p>
                                    </div>
                                  )}

                                  {check.notes && (
                                    <div className="bg-zinc-50 border border-zinc-150 p-2.5 rounded-xl">
                                      <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-wider block mb-0.5">
                                        General Notes
                                      </span>
                                      <p className="text-zinc-700 leading-snug">{check.notes}</p>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Action Buttons Footer (Not in Edit Mode) */}
              {!isEditMode && (
                <div className="p-6 border-t border-zinc-200 bg-zinc-50/50 flex flex-wrap gap-3 justify-between items-center">
                  <div>
                    {selectedGoal.userId === currentUserId &&
                      (selectedGoal.status === "DRAFT" ||
                        selectedGoal.status === "RETURNED_FOR_REWORK") && (
                        <button
                          onClick={() => handleDeleteGoal(selectedGoal.id)}
                          className="flex items-center gap-1.5 py-2.5 px-4 text-xs font-bold text-rose-600 hover:text-rose-700 transition-colors border border-rose-250 hover:bg-rose-50 rounded-xl cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" /> Delete
                        </button>
                      )}
                  </div>

                  <div className="flex gap-2">
                    {/* Employee Edit Trigger */}
                    {selectedGoal.userId === currentUserId &&
                      (selectedGoal.status === "DRAFT" ||
                        selectedGoal.status === "RETURNED_FOR_REWORK") && (
                        <button
                          onClick={() => openEditMode(selectedGoal)}
                          className="flex items-center gap-1.5 py-2.5 px-4 text-xs font-semibold border border-zinc-250 hover:bg-zinc-100 rounded-xl transition-colors cursor-pointer"
                        >
                          <Edit2 className="w-3.5 h-3.5" /> Edit Details
                        </button>
                      )}

                    {/* Employee Submit Trigger */}
                    {selectedGoal.userId === currentUserId &&
                      (selectedGoal.status === "DRAFT" ||
                        selectedGoal.status === "RETURNED_FOR_REWORK") && (
                        <button
                          onClick={() => handleSubmitGoal(selectedGoal.id)}
                          className="flex items-center gap-1.5 py-2.5 px-5 bg-[var(--color-dijon)] text-white text-xs font-semibold rounded-xl hover:bg-[var(--color-dijon)]/95 shadow-sm transition-all cursor-pointer"
                        >
                          <Send className="w-3.5 h-3.5" /> Submit to Manager
                        </button>
                      )}

                    {/* Employee Withdraw Trigger */}
                    {selectedGoal.userId === currentUserId &&
                      selectedGoal.status === "SUBMITTED" && (
                        <button
                          onClick={() => handleWithdrawGoal(selectedGoal.id)}
                          className="flex items-center gap-1.5 py-2.5 px-5 border border-zinc-250 hover:bg-zinc-100 text-xs font-semibold rounded-xl transition-colors cursor-pointer"
                        >
                          <ArrowRight className="w-3.5 h-3.5 rotate-180" /> Withdraw to Draft
                        </button>
                      )}

                    {/* Manager Approval & Rework Actions */}
                    {selectedGoal.user.managerId === currentUserId &&
                      selectedGoal.status === "SUBMITTED" && (
                        <>
                          <button
                            onClick={() => setShowReworkInput(true)}
                            className="flex items-center gap-1 py-2.5 px-4 border border-orange-200 text-orange-700 bg-orange-50/50 hover:bg-orange-50 text-xs font-semibold rounded-xl cursor-pointer"
                          >
                            <AlertTriangle className="w-3.5 h-3.5" /> Rework feedback
                          </button>
                          <button
                            onClick={handleApprove}
                            className="flex items-center gap-1.5 py-2.5 px-5 bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-semibold rounded-xl shadow-sm cursor-pointer"
                          >
                            <UserCheck className="w-4 h-4" /> Approve Goal
                          </button>
                        </>
                      )}
                  </div>
                </div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// DROPPABLE COLUMN COMPONENT FOR KANBAN BOARD
function DroppableColumn({
  id,
  title,
  count,
  children,
  bgClass
}: {
  id: string;
  title: string;
  count: number;
  children: React.ReactNode;
  bgClass: string;
}) {
  const { isOver, setNodeRef } = useDroppable({
    id: id
  });

  return (
    <div
      ref={setNodeRef}
      className={`flex flex-col gap-4 p-4 rounded-2xl w-[235px] min-w-[235px] shrink-0 h-[620px] transition-all border ${bgClass} ${
        isOver ? "bg-amber-50/60 border-2 border-dashed border-[var(--color-dijon)]/50 ring-4 ring-amber-100/5 shadow-inner" : ""
      }`}
    >
      <div className="flex justify-between items-center border-b border-zinc-200/50 pb-2">
        <h3 className="font-bold text-xs uppercase tracking-wider text-zinc-600 flex items-center gap-2">
          <span
            className={`w-2 h-2 rounded-full ${
              id === "DRAFT"
                ? "bg-zinc-400"
                : id === "SUBMITTED"
                ? "bg-blue-500"
                : id === "RETURNED_FOR_REWORK"
                ? "bg-orange-500"
                : id === "APPROVED"
                ? "bg-amber-500"
                : "bg-green-500"
            }`}
          />
          {title}
        </h3>
        <span className="bg-white/80 dark:bg-zinc-900 border border-zinc-200/80 px-2 py-0.5 rounded-full text-[10px] font-extrabold text-zinc-500 shadow-sm">
          {count}
        </span>
      </div>

      <div className="flex flex-col gap-3 flex-1 overflow-y-auto">
        {React.Children.count(children) === 0 ? (
          <div className="border border-dashed border-zinc-200 rounded-xl p-6 text-center flex flex-col justify-center items-center h-28 my-auto">
            <span className="text-[10px] text-zinc-400 font-semibold italic">Drop cards here</span>
          </div>
        ) : (
          children
        )}
      </div>
    </div>
  );
}

// DRAGGABLE CARD COMPONENT WITH DRAG HANDLE TO PREVENT INTERFERENCE WITH BUTTON CLICKS
function DraggableGoalCard({
  goal,
  onClick,
  getPriorityBadgeColor
}: {
  goal: Goal;
  onClick: () => void;
  getPriorityBadgeColor: (p: Goal["priority"]) => string;
}) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: goal.id
  });

  const style = {
    transform: CSS.Translate.toString(transform),
    opacity: isDragging ? 0.35 : 1,
    zIndex: isDragging ? 50 : undefined
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="bg-white border border-zinc-200 hover:border-zinc-300 p-4 rounded-xl shadow-sm hover:shadow-md transition-all flex flex-col gap-3 group relative select-none"
    >
      {/* Top row */}
      <div className="flex justify-between items-start gap-2">
        <span
          className={`text-[9px] font-extrabold tracking-wider px-2 py-0.5 rounded-md border ${getPriorityBadgeColor(
            goal.priority
          )}`}
        >
          {goal.priority}
        </span>

        {/* Drag handle specifically holds listeners & attributes to avoid interfering with body clicks */}
        <div
          {...listeners}
          {...attributes}
          className="p-1 rounded text-zinc-400 hover:text-zinc-650 hover:bg-zinc-100 active:cursor-grabbing cursor-grab shrink-0 transition-colors"
        >
          <GripVertical className="w-4 h-4" />
        </div>
      </div>

      {/* Title */}
      <div className="cursor-pointer" onClick={onClick}>
        <h4 className="font-semibold text-sm text-zinc-850 line-clamp-2 leading-snug group-hover:text-[var(--color-dijon)] transition-colors">
          {goal.title}
        </h4>
        {goal.description && (
          <p className="text-zinc-400 text-xs line-clamp-1 mt-1 font-medium">{goal.description}</p>
        )}
      </div>

      {/* Progress & Weights */}
      <div className="space-y-1.5 cursor-pointer mt-1" onClick={onClick}>
        <div className="flex justify-between items-center text-[10px] text-zinc-500 font-bold">
          <span className="flex items-center gap-1">
            Progress: <b>{goal.progress}%</b>
          </span>
          <span>Weight: {goal.weightage}%</span>
        </div>
        <div className="w-full bg-zinc-100 rounded-full h-1.5">
          <div
            className="bg-[var(--color-dijon)] h-1.5 rounded-full transition-all duration-300"
            style={{ width: `${goal.progress}%` }}
          />
        </div>
      </div>

      {/* Footer Info */}
      <div className="flex justify-between items-center border-t border-zinc-100 pt-2.5 mt-1.5 text-[10px] text-zinc-550 font-semibold">
        <span className="flex items-center gap-1">
          <Calendar className="w-3.5 h-3.5 text-zinc-400" />
          {goal.dueDate ? new Date(goal.dueDate).toLocaleDateString() : "No Date"}
        </span>

        <button
          onClick={onClick}
          className="text-[var(--color-dijon)] hover:underline flex items-center gap-0.5 hover:gap-1 transition-all"
        >
          Details <ChevronRight className="w-3 h-3" />
        </button>
      </div>
    </div>
  );
}
