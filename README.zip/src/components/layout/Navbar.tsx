"use client";

import { useState } from "react";
import { useSession, signOut } from "next-auth/react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, X, Mail, ShieldCheck, Calendar } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";

export function Navbar() {
  const { data: session } = useSession();
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  return (
    <>
      <header className="h-16 bg-white border-b border-zinc-200 flex items-center justify-between px-6 sticky top-0 z-40">
        <div className="flex items-center md:hidden">
          <Sheet>
            <SheetTrigger render={<Button variant="ghost" size="icon" className="-ml-2" />}>
              <Menu className="w-5 h-5" />
            </SheetTrigger>
            <SheetContent side="left" className="w-64 p-0">
              <div className="h-16 flex items-center px-6 border-b border-zinc-200 font-poppins font-bold text-xl">
                 Enterprise<span className="text-[var(--color-dijon)]">Goals</span>
              </div>
              <div className="p-4 text-zinc-500 text-sm">Use desktop sidebar for navigation.</div>
            </SheetContent>
          </Sheet>
        </div>

        <div className="flex-1" />

        <div className="flex items-center gap-4">
          <DropdownMenu>
            <DropdownMenuTrigger render={<Button variant="ghost" className="relative h-8 w-8 rounded-full" />}>
              <Avatar className="h-8 w-8">
                <AvatarFallback className="bg-[var(--color-dijon)] text-white">
                  {session?.user?.name?.charAt(0) || "U"}
                </AvatarFallback>
              </Avatar>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end">
              <DropdownMenuLabel className="font-normal">
                <div className="flex flex-col space-y-1">
                  <p className="text-sm font-medium leading-none">{session?.user?.name}</p>
                  <p className="text-xs leading-none text-muted-foreground">{session?.user?.email}</p>
                  <p className="text-xs leading-none text-[var(--color-dijon)] font-medium mt-1">{session?.user?.role}</p>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setIsProfileOpen(true)} className="cursor-pointer">
                Profile Details
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => signOut()} className="cursor-pointer text-rose-600 focus:bg-rose-50">
                Log out
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      {/* PROFILE DETAILS DIALOG MODAL */}
      <AnimatePresence>
        {isProfileOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center">
            {/* Backdrop overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsProfileOpen(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-xs"
            />
            {/* Modal Card content */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="bg-white rounded-3xl p-8 max-w-sm w-full border border-zinc-150 shadow-2xl relative z-10 mx-4 overflow-hidden"
            >
              {/* Decorative radial gradient blob */}
              <div className="absolute top-0 right-0 w-32 h-32 rounded-full bg-[var(--color-mimosa)]/10 filter blur-xl pointer-events-none" />
              
              <div className="flex justify-between items-start mb-6 relative z-10">
                <h3 className="text-lg font-bold text-zinc-900 font-poppins">My Profile</h3>
                <button
                  onClick={() => setIsProfileOpen(false)}
                  className="p-1 rounded-lg hover:bg-zinc-100 text-zinc-400 hover:text-zinc-650 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex flex-col items-center text-center relative z-10">
                {/* Stylised Avatar profile circle */}
                <div className="w-20 h-20 rounded-full bg-amber-50 border-4 border-white shadow-md flex items-center justify-center text-3xl font-bold text-[var(--color-dijon)] mb-4 ring-2 ring-[var(--color-dijon)]/20">
                  {session?.user?.name?.charAt(0) || "U"}
                </div>

                <h4 className="text-xl font-bold text-zinc-900">{session?.user?.name}</h4>
                <span className="text-xs font-semibold px-3 py-1 rounded-full bg-zinc-100 border border-zinc-200 text-zinc-700 mt-1.5 uppercase tracking-wider">
                  {session?.user?.role}
                </span>

                <div className="w-full border-t border-zinc-100 my-6" />

                {/* Grid details items list */}
                <div className="w-full space-y-4 text-left">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-zinc-50 border border-zinc-200/60 text-zinc-500">
                      <Mail className="w-4.5 h-4.5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-400 font-bold tracking-wider uppercase block">Email Address</span>
                      <span className="text-sm font-semibold text-zinc-800">{session?.user?.email}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-zinc-50 border border-zinc-200/60 text-zinc-500">
                      <ShieldCheck className="w-4.5 h-4.5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-400 font-bold tracking-wider uppercase block">Access Tier</span>
                      <span className="text-xs font-semibold text-zinc-700">
                        {session?.user?.role === "ADMIN" 
                          ? "Full Read/Write Sandbox Permissions" 
                          : session?.user?.role === "MANAGER" 
                          ? "Team Management & Approvals Tier" 
                          : "Standard Objectives Creator Tier"}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-zinc-50 border border-zinc-200/60 text-zinc-500">
                      <Calendar className="w-4.5 h-4.5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-400 font-bold tracking-wider uppercase block">Auth Sandbox Session</span>
                      <span className="text-xs font-medium text-zinc-500">
                        Secured session cookie verified by NextAuth credentials provider
                      </span>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => setIsProfileOpen(false)}
                  className="w-full mt-8 py-2.5 bg-zinc-900 text-white font-semibold rounded-xl hover:bg-zinc-850 transition-colors shadow-lg shadow-zinc-900/10 cursor-pointer text-sm font-sans"
                >
                  Close Profile
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
