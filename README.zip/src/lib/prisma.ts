import { PrismaClient } from "@prisma/client";
import { PrismaLibSql } from "@prisma/adapter-libsql";
import path from "path";

const dbPath = path.resolve(process.cwd(), "prisma", "dev.db");
const url = `file:${dbPath}`;

const globalForPrisma = globalThis as unknown as { prisma: PrismaClient };

function createPrismaClient() {
  console.log("createPrismaClient: url =", url);
  const adapter = new PrismaLibSql({ url });
  return new PrismaClient({ adapter });
}

// Always create fresh in dev to avoid stale cache issues
if (process.env.NODE_ENV !== "production") {
  delete (globalForPrisma as any).prisma;
}

export const prisma = globalForPrisma.prisma ?? createPrismaClient();

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
