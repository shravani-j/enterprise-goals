import { prisma } from '../src/lib/prisma';
import bcrypt from 'bcryptjs';

async function main() {
  console.log('Seeding database...');

  const hashedPassword = await bcrypt.hash('Password123', 10);

  // Create an Admin
  const admin = await prisma.user.upsert({
    where: { email: 'admin@enterprise.com' },
    update: { password: hashedPassword },
    create: {
      name: 'System Admin',
      email: 'admin@enterprise.com',
      password: hashedPassword,
      role: 'ADMIN',
    },
  });

  // Create a Manager
  const manager = await prisma.user.upsert({
    where: { email: 'manager@enterprise.com' },
    update: { password: hashedPassword },
    create: {
      name: 'Sales Manager',
      email: 'manager@enterprise.com',
      password: hashedPassword,
      role: 'MANAGER',
    },
  });

  // Create Employees
  const employee1 = await prisma.user.upsert({
    where: { email: 'employee1@enterprise.com' },
    update: { password: hashedPassword, managerId: manager.id },
    create: {
      name: 'John Doe',
      email: 'employee1@enterprise.com',
      password: hashedPassword,
      role: 'EMPLOYEE',
      managerId: manager.id,
    },
  });

  const employee2 = await prisma.user.upsert({
    where: { email: 'employee2@enterprise.com' },
    update: { password: hashedPassword, managerId: manager.id },
    create: {
      name: 'Jane Smith',
      email: 'employee2@enterprise.com',
      password: hashedPassword,
      role: 'EMPLOYEE',
      managerId: manager.id,
    },
  });

  console.log('Database seeded successfully.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
